package com.lt.sdk.event;

/** SdkCallBack.java:用于返回客户端是否 ----- 2018-10-16 下午7:04:02 wangzhongyuan */
public interface SdkCallBack
{
    // 成功
    public void OnSuccess();

    // 失败
    public void Onfail();

}